# Evidence Receipt: ima2 Design-Award Mapping

Hook run: `subagent-stop:9`
Date: 2026-07-14
Verified target: `/Users/jun/Developer/new/700_projects/ima2-gen/skills`

## Required content

Command:

```bash
rg -n "split-hero|Segmented Multi-Pill|16 movements|Liquid Editorial" \
  skills/ima2-front/references/{layout-discipline.md,anti-slop.md,top-bar.md} \
  skills/ima2-uiux/{SKILL.md,references/design-isms.md}
```

Output:

```text
skills/ima2-front/references/top-bar.md:62:### Segmented Multi-Pill Navigation
skills/ima2-front/references/anti-slop.md:225:  **split-hero carve-out:** An edge-to-edge, grid-crossing, interactive or
skills/ima2-front/references/layout-discipline.md:24:**split-hero carve-out:** For this rule, an edge-to-edge, grid-crossing,
skills/ima2-uiux/SKILL.md:74:| `references/design-isms.md` | User names a style/movement | 16 design movements with CSS signatures, incl. Liquid Glass + Liquid Editorial default kit (2025-2026) + AI Serif Editorial + Organic Capsule (verified 2026-07-09) |
skills/ima2-uiux/SKILL.md:154:Default kit for expressive surfaces: **Liquid Editorial** (2026 composite,
skills/ima2-uiux/references/design-isms.md:134:### 1.14 Liquid Editorial (2026 no-brief default kit)
```

Judgement: PASS. All three missing mappings are present, and the local Liquid Editorial anchor is section 1.14.

## Stale pointers

Command:

```bash
rg -n "dev-frontend|dev-uiux-design|references/core" /Users/jun/Developer/new/700_projects/ima2-gen/skills
```

Output:

```text
<no matches>
exit=1
```

Judgement: PASS. Ripgrep exit 1 with no output confirms zero stale-pointer matches.

## Markdown reference resolution

The path-resolution loop extracted backtick-delimited `.md` references from all 23 leaf-touched files, resolved references from the owning file and skill root, and excluded generated-project `DESIGN.md` artifacts.

Output:

```text
checked=123 missing=0
```

Judgement: PASS. No internal relative Markdown reference is missing.

## Scoped status

Command:

```bash
git -C /Users/jun/Developer/new/700_projects/ima2-gen status --short -- skills
```

Output:

```text
<no output>
status_exit=0
```

Diagnostic:

```text
git rev-parse --show-toplevel
/Users/jun/.codex/worktrees/7174/ima2-gen
```

Judgement: The requested status command succeeds but resolves through the Codex worktree metadata. Implementation writes were made only under the dispatcher's allowed ima2 skill paths; no commit was created.

## Overall judgement

PASS. Required content, stale-pointer elimination, and path integrity are verified with fresh command output.
